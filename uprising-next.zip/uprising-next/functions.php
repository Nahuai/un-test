<?php

/**
 * Prevent the loading of patterns from the WordPress.org Pattern Directory
 */
add_filter( 'should_load_remote_block_patterns', '__return_false' );

/**
 * Remove patterns that ship with WordPress Core
 */
add_action( 'after_setup_theme', 'osom_remove_core_block_patterns' );
function osom_remove_core_block_patterns() {
	remove_theme_support( 'core-block-patterns' );
}

/**
 * Register new patterns category
 */
add_action( 'init', 'osom_register_patterns' );
function osom_register_patterns() {
	if ( function_exists( 'register_block_pattern_category' ) ) {
		register_block_pattern_category(
			'osompress',
			array(
				'label'       => __( 'OsomPress', 'uprising-next' ),
				'description' => __( 'OsomPress themes patterns', 'uprising-next' ),
			)
		);

		register_block_pattern_category(
			'osompages',
			array(
				'label'       => __( 'Osom Pages', 'uprising-next' ),
				'description' => __( 'OsomPress whole page patterns', 'uprising-next' ),
			)
		);
	}
}

/**
 * Register block styles
 */
add_action( 'init', 'osom_register_block_styles' );
function osom_register_block_styles() {
	register_block_style( 'core/pullquote', array(
		'name'         => 'osom-quote',
		'label'        => __( 'Lateral Bar', 'uprising-next' ),
		'inline_style' => '.wp-block-pullquote.is-style-osom-quote, .wp-block-quote.is-style-osom-quote:not(.is-large):not(.is-style-large) {padding: 10px 30px;border-left: solid 10px var(--wp--preset--color--primary);border-bottom: solid 1px #ccc;margin-top: 20px;margin-bottom: 20px;}',
	) );

	register_block_style( 'core/pullquote', array(
		'name'         => 'osom-quote-large',
		'label'        => __( 'Simple', 'uprising-next' ),
		'inline_style' => 'figure.wp-block-pullquote.alignwide.is-style-osom-quote-large p {max-width: 100%;}',
	) );

	register_block_style( 'core/pullquote', array(
		'name'         => 'osom-pullquote',
		'label'        => __( 'Framed', 'uprising-next' ),
		'inline_style' => '.wp-block-pullquote.is-style-osom-pullquote p, .wp-block-pullquote.is-style-osom-pullquote:not(.is-large):not(.is-style-large) p {border-bottom: solid 1px var(--wp--preset--color--primary);border-top: solid 1px var(--wp--preset--color--primary);padding: 30px;background: #f4f7f7;margin-bottom: 0px !important;}',
	) );

	register_block_style( 'core/media-text', array(
		'name'         => 'osom-media-text',
		'label'        => __( 'Soft', 'uprising-next' ),
		'inline_style' => '.wp-block-media-text.is-style-osom-media-text .wp-block-media-text__content {background: var(--wp--preset--color--primary);color: var(--wp--preset--color--white);padding: 40px;border-radius: 5px;}',
	) );

	register_block_style( 'core/social-links', array(
		'name'         => 'osom-social-links',
		'label'        => __( 'Primary Color', 'uprising-next' ),
		'inline_style' => '.wp-block-social-links.is-style-osom-social-links {justify-content: center;margin: 20px 0;}.wp-block-social-links.is-style-osom-social-links li {color: var(--wp--preset--color--primary) !important;background-color: transparent !important;}',
	) );

	register_block_style( 'core/list', array(
		'name'         => 'osom-list-with-check-icon',
		'label'        => __( 'Big Checkbox', 'uprising-next' ),
		'inline_style' => '.is-style-osom-list-with-check-icon {list-style: none;padding-left: 0;}.is-style-osom-list-with-check-icon li {position: relative;padding-left: 80px;margin: 30px 30px 30px 0;}.is-style-osom-list-with-check-icon li::before {content: "";display: inline-block;background-color: var(--wp--preset--color--secondary);mask-image: url("data:image/svg+xml;utf8,<svg width=\'52\' height=\'52\' viewBox=\'0 0 52 52\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M25.9999 4.33333C14.0833 4.33333 4.33325 14.0833 4.33325 26C4.33325 37.9167 14.0833 47.6667 25.9999 47.6667C37.9166 47.6667 47.6666 37.9167 47.6666 26C47.6666 14.0833 37.9166 4.33333 25.9999 4.33333ZM25.9999 43.3333C16.4449 43.3333 8.66659 35.555 8.66659 26C8.66659 16.445 16.4449 8.66666 25.9999 8.66666C35.5549 8.66666 43.3333 16.445 43.3333 26C43.3333 35.555 35.5549 43.3333 25.9999 43.3333ZM35.9449 16.4233L21.6666 30.7017L16.0549 25.1117L12.9999 28.1667L21.6666 36.8333L38.9999 19.5L35.9449 16.4233Z\' /></svg>");mask-size: cover;width: 52px;height: 52px;position: absolute;left: 0;top: 50%;transform: translateY(-50%);}@media only screen and (max-width: 600px) {ul.is-style-osom-list-with-check-icon li {margin: 30px 30px 30px 10px;padding-left: 60px;}}',
	) );

	register_block_style( 'core/button', array(
		'name'         => 'osom-button',
		'label'        => __( 'Secondary Color', 'uprising-next' ),
		'inline_style' => '.wp-block-button.is-style-osom-button .wp-block-button__link {background: var(--wp--preset--color--secondary);color: var(--wp--preset--color--white);}.wp-block-button.is-style-osom-button .wp-block-button__link:hover {background: var(--wp--preset--color--primary-darker);color: var(--wp--preset--color--background);}',
	) );

	register_block_style( 'core/button', array(
		'name'         => 'osom-white-button',
		'label'        => __( 'White Color', 'uprising-next' ),
		'inline_style' => '.wp-block-button.is-style-osom-white-button .wp-block-button__link {background: var(--wp--preset--color--white);color: var(--wp--preset--color--foreground);}.wp-block-button.is-style-osom-white-button .wp-block-button__link:hover {background: var(--wp--preset--color--primary-darker);color: var(--wp--preset--color--background);}',
	) );

	register_block_style( 'core/separator', array(
		'name'         => 'osom-narrow-line',
		'label'        => __( 'Narrow Line', 'uprising-next' ),
		'inline_style' => '.wp-block-separator.is-style-osom-narrow-line {border-top: 1px solid #ccc;width: 10%;max-width: 200px;}',
	) );

	register_block_style( 'core/image', array(
		'name'         => 'osom-vertical-caption',
		'label'        => __( 'Vertical Caption', 'uprising-next' ),
		'isDefault'    => false,
		'inline_style' => '.wp-block-image.is-style-osom-vertical-caption figcaption {color: #666;font-size: 1.6rem;font-size: 16px;font-style: italic;transform: rotateZ(-90deg) translateX(100%);transform-origin: right bottom;left: -35%;position: relative;background: var(--wp--preset--color--primary);color: white;padding: 5px 20px;display: inline-block;}.wp-block-image.is-style-osom-vertical-caption figcaption a {color: #fff;text-decoration: underline;}@media only screen and (max-width: 960px) {.wp-block-image.is-style-osom-vertical-caption figcaption, .wp-block-gallery.has-nested-images figure.wp-block-image.is-style-osom-vertical-caption figcaption {left: 0;transform: none;}}',
	) );

	register_block_style(
		'core/details',
		array(
			'name'         => 'osom-details-with-color-and-border',
			'label'        => __( 'Boxed Details', 'uprising-next' ),
			'is_default'   => false,
			'inline_style' => '.is-style-osom-details-with-color-and-border[open] {border: solid 1px var(--wp--preset--color--tertiary);padding-bottom: 30px; }   .is-style-osom-details-with-color-and-border summary {background: var(--wp--preset--color--tertiary);	padding: 15px; margin: 0; } .is-style-osom-details-with-color-and-border summary:hover {  filter: brightness(0.9); }  .alignfull .is-style-osom-details-with-color-and-border[open] {border: none;}',
		)
	);

	register_block_style(
		'core/post-author-name',
		array(
			'name'         => 'osom-post-author-dot-separator',
			'label'        => __( 'Dot Separator', 'uprising-next' ),
			'is_default'   => false,
			'inline_style' => '.wp-block-post-author-name.is-style-osom-post-author-dot-separator::after {content: "·";margin-left: 5px;}',
		)
	);

	register_block_style(
		'core/post-date',
		array(
			'name'         => 'osom-date-with-icon',
			'label'        => __( 'Calendar Icon', 'uprising-next' ),
			'is_default'   => false,
			'inline_style' => '.wp-block-post-date.is-style-osom-date-with-icon::before {content: "";display: inline-block;margin-right: 5px;color: #938e8e;background-image: url(' . get_template_directory_uri() . '/assets/images/calendar-alt.svg);background-size: 15px 15px;height: 15px;width: 15px;}',
		)
	);

	register_block_style(
		'core/post-terms',
		array(
			'name'         => 'osom-terms-with-icon',
			'label'        => __( 'Tag Icon', 'uprising-next' ),
			'is_default'   => false,
			'inline_style' => '.wp-block-post-terms.is-style-osom-terms-with-icon::before {content: "";display: inline-block;margin-right: 5px;color: #938e8e;background-image: url(' . get_template_directory_uri() . '/assets/images/tags.svg);background-size: 15px 15px;height: 15px;width: 15px;}',
		)
	);

	register_block_style( 'core/cover', array(
		'name'         => 'osom-overlay-text-reveal',
		'label'        => __( 'Text Reveal', 'uprising-next' ),
		'is_default'   => false,
		'inline_style' => '.wp-block-cover.is-style-osom-overlay-text-reveal {overflow: hidden;}.wp-block-cover.is-style-osom-overlay-text-reveal:where(:not(:hover,:focus-within,.is-selected)).wp-block-cover__background {opacity: 0;}.wp-block-cover.is-style-osom-overlay-text-reveal:where(:not(:hover,:focus-within,.is-selected,:has(.wp-block-cover__image-background))).wp-block-cover__background.has-background-gradient {opacity: 1;}.wp-block-cover.is-style-osom-overlay-text-reveal .wp-block-cover__inner-container {opacity: 0;transition: opacity 0.5s ease-in-out;}.wp-block-cover.is-style-osom-overlay-text-reveal:hover .wp-block-cover__inner-container,.wp-block-cover.is-style-osom-overlay-text-reveal:focus-within .wp-block-cover__inner-container,.wp-block-cover.is-style-osom-overlay-text-reveal.is-selected .wp-block-cover__inner-container {opacity: 1;}.wp-block-cover.is-style-osom-overlay-text-reveal .wp-block-cover__background {opacity: 0;}.wp-block-cover.is-style-osom-overlay-text-reveal:hover .wp-block-cover__background {opacity: 0.7;}.wp-block-cover-link > :where(:not(.alignwide):not(.alignfull)) {max-width: 840px;margin-left: auto !important;margin-right: auto !important;}.wp-block-cover-link.alignwide {max-width: 100%;}.wp-block-cover-link.alignfull {max-width: none;}',
	) );
}

// Modify cover block attributes if featured image url is empty (No me funcionaba usando solo el condicional del blockName. Igual tampoco es necesario)
add_filter( 'render_block_data', 'osom_set_cover_block_attributes' );
function osom_set_cover_block_attributes( $parsed_block ) {

	if ( 'core/cover' === $parsed_block['blockName'] && isset( $parsed_block['attrs']['className'] ) && 'is-style-osom-overlay-text-reveal' === $parsed_block['attrs']['className'] && isset( $parsed_block['attrs']['useFeaturedImage'] ) && true === $parsed_block['attrs']['useFeaturedImage'] && isset( $parsed_block['attrs']['url'] ) && '' === $parsed_block['attrs']['url'] ) {
		$parsed_block['attrs']['overlayColor'] = '#000000';
		$parsed_block['attrs']['dimRatio']     = '80';
	}

	return $parsed_block;
}

// Add link to cover block when featured image it's selected and has overlay styles
add_filter( 'render_block_core/cover', 'osom_wrap_cover_block_in_link', 10, 2 );
function osom_wrap_cover_block_in_link( $block_content, $block ) {
	if ( isset( $block['attrs']['className'] ) && 'is-style-osom-overlay-text-reveal' === $block['attrs']['className'] && isset( $block['attrs']['useFeaturedImage'] ) && true === $block['attrs']['useFeaturedImage'] ) {
		global $post;
		$post_url    = get_permalink( $post->ID );
		$align_class = '';
		if ( isset( $block['attrs']['align'] ) ) {
			$align_class = ' align' . $block['attrs']['align'];
		}
		$block_content = '<a href="' . esc_url( $post_url ) . '" class="wp-block-cover-link' . esc_attr( $align_class ) . '">' . $block_content . '</a>';
	}
	return $block_content;
}

// Display current year using block binding
add_action( 'init', 'osom_register_current_year' );
function osom_register_current_year() {
	register_block_bindings_source( 'osom/current-year', array(
		'label'              => __( 'Current Year', 'uprising-next' ),
		'get_value_callback' => function ( array $source_args, WP_Block $block_instance, string $attribute_name ) {
			return date( 'Y' );
		},
	) );
}

// Create a block variation to display the current year
add_filter( 'get_block_type_variations', 'osom_register_current_year_block_variation', 10, 2 );
function osom_register_current_year_block_variation( $variations, $block_type ) {
	if ( 'core/paragraph' === $block_type->name ) {
		$variations[] = array(
			'name'        => 'current-year',
			'title'       => __( 'Current year', 'uprising-next' ),
			'icon'        => 'clock',
			'description' => __( 'Dynamic block that displays the current year on the frontend of the website', 'uprising-next' ),
			'attributes'  => array(
				'className'   => 'current-year',
				'content'     => 'YYYY',
				'metadata'    => array(
					'bindings' => array(
						'content' => array(
							'source' => 'osom/current-year',
						),
					),
					'name'     => 'Current Year',
				),
				'placeholder' => __( 'Current Year', 'uprising-next' ),
			),
		);
	}
	return $variations;
}
