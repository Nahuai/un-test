=== Uprising Next ===
Contributors: OsomPress
Requires at least: 6.6
Tested up to: 6.6
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Uprising Next is a WordPress block theme thoughtfully designed with big and small companies in mind, but thanks to the layout features of Site Editing, you can easily adapt it for any type of website. 

With its modern design, clean code and fast-loading performance, it ensures your website runs smoothly. Fully compatible with the Site Editor, Osom Business theme lets you choose more than 18 page and block patterns and enjoy three style variations to customize your online presence with ease, empowering you to showcase your brand effortlessly and professionally.

Documentation and more info: https://osompress.com/theme/uprising-next/
Demo - Live preview: https://demo.osompress.com/uprising-next/


== Changelog ==

= 1.0.0 =
* Initial release

== Copyright ==

Uprising Next WordPress Theme, (C) 2023 OsomPress
Uprising Next is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Montserrat Font
Copyright 2011 The Montserrat Project Authors (https://github.com/JulietaUla/Montserrat)
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: https://scripts.sil.org/OFL 
License URL: https://scripts.sil.org/OFL  
-- End of Montserrat Font credits --

Open Sans Font
Copyright 2020 The Open Sans Project Authors (https://github.com/googlefonts/opensans)
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: https://scripts.sil.org/OFL 
License URL: https://scripts.sil.org/OFL 
-- End of Open Sans Font credits --

Playfair Font
Copyright 2005–2023 The Playfair Project Authors (https://github.com/clauseggers/Playfair)
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: https://scripts.sil.org/OFL 
License URL: https://scripts.sil.org/OFL 
-- End of Playfair Font credits --

Arsenal Font
Copyright 2012 The Arsenal Project Authors (andrij.design@gmail.com) 
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: http://scripts.sil.org/OFL 
License URL: http://scripts.sil.org/OFL 
Source: http://stairsfor.com/
-- End of Arsenal Font credits --


Images and Icons for demo content

Taken with an unknown camera 10/07 2018  
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/es/photo/1561913

Taken with an unknown camera 02/09 2017  
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/es/photo/1561913

@Uerpear,taken with an unknown camera 11/05 2021  
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/es/photo/1649307

Taken with an unknown camera 03/04 2017
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/es/photo/965244

Taken with an unknown camera 04/11 2017
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/es/photo/1390062

Taken with an Canon EOS 7D 03/03 2017 The picture taken with 18.0mm, f/13.0s, 1/30s, ISO 200 
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/943456

Taken with an unknown camera 03/18 2017
License: Creative Commons CC0.
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1181792

