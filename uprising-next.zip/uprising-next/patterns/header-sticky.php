<?php
/**
 * Title: Sticky Header
 * Slug: uprising-next/sticky-header
 * Categories: header
 * Block Types: core/template-part/header
 *
 * @package uprising-next
 * @since 0.9.0
 */
?>

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"margin":{"top":"0","bottom":"0"},"blockGap":"0","padding":{"top":"0","right":"var:preset|spacing|medium","bottom":"0","left":"var:preset|spacing|medium"}},"position":{"type":"sticky","top":"0px"},"border":{"bottom":{"color":"var:preset|color|tertiary","width":"1px"},"top":{},"right":{},"left":{}}},"backgroundColor":"background","textColor":"base","layout":{"inherit":"true","type":"constrained"}} -->
<div class="wp-block-group has-base-color has-background-background-color has-text-color has-background has-link-color" style="border-bottom-color:var(--wp--preset--color--tertiary);border-bottom-width:1px;margin-top:0;margin-bottom:0;padding-top:0;padding-right:var(--wp--preset--spacing--medium);padding-bottom:0;padding-left:var(--wp--preset--spacing--medium)"><!-- wp:group {"align":"full","style":{"spacing":{"padding":{"bottom":"30px","top":"30px","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}},"layout":{"type":"flex","justifyContent":"space-between"}} -->
<div class="wp-block-group alignfull" style="padding-top:30px;padding-right:var(--wp--preset--spacing--medium);padding-bottom:30px;padding-left:var(--wp--preset--spacing--medium)"><!-- wp:group {"style":{"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"flex"}} -->
<div class="wp-block-group" style="padding-right:0;padding-left:0"><!-- wp:site-logo {"width":150,"shouldSyncIcon":true} /--></div>
<!-- /wp:group -->

<!-- wp:navigation {"textColor":"foreground","overlayBackgroundColor":"background","overlayTextColor":"primary","layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|medium"},"typography":{"textTransform":"uppercase"}},"fontSize":"small","fontFamily":"heading"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->