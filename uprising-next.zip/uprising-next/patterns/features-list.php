<?php
/**
 * Title: Features List
 * Slug: uprising-next/features
 * Categories: osompress
 *
 */
?>

<!-- wp:group {"align":"full","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Our Promise</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"padding":{"right":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<p class="has-text-align-center" style="padding-right:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)">At Calm Interiors, we pride ourselves on delivering exceptional design services that cater to your unique needs. Here are some of the standout features of our offerings:</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:list {"className":"is-style-osom-list-with-check-icon"} -->
<ul class="is-style-osom-list-with-check-icon"><!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<li style="margin-top:0;margin-bottom:0">We tailor our design solutions to your preferences. Our team works closely with you to ensure every detail reflects your style and enhances your space.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>From concept to completion, we manage every aspect of your project. This includes coordinating with contractors and scheduling to ensure timely and efficient execution.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Our expert consultation services offer professional guidance on color schemes, furniture selection, and spatial layout to help you make informed decisions.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:list {"className":"is-style-osom-list-with-check-icon"} -->
<ul class="is-style-osom-list-with-check-icon"><!-- wp:list-item {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<li style="margin-top:0;margin-bottom:0">We are committed to sustainability, using eco-friendly materials and energy-efficient solutions to create beautiful, environmentally responsible spaces.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Our team stays updated with the latest design trends and technologies, incorporating innovative concepts to create functional and stylish designs.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>We offer dedicated support throughout your project. Our team is always available to answer questions, address concerns, and provide updates, ensuring a smooth experience.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
