<?php
/**
 * Title: Contact Page
 * Slug: uprising-next/page-contact
 * Categories: osompages, contact
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 *
 */
?>

<!-- wp:image {"id":145,"sizeSlug":"full","linkDestination":"none","align":"center","className":"is-style-osom-vertical-caption"} -->
<figure class="wp-block-image aligncenter size-full is-style-osom-vertical-caption"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-2.webp" alt="" class="wp-image-145"/><figcaption class="wp-element-caption"><strong>Welcome to Your Dream Space</strong></figcaption></figure>
<!-- /wp:image -->

<!-- wp:spacer {"height":"29px"} -->
<div style="height:29px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Ready To Transform Your Space?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Reach out to us today to schedule a consultation. Let Calm Interiors bring your dream space to life.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/placeholder-form"} /-->
