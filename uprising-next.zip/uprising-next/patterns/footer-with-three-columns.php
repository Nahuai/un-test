<?php
/**
 * Title: Footer with three columns
 * Slug: uprising-next/footer-with-three-columns
 * Categories: footer
 * Block Types: core/template-part/footer
 */
?>

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"},"blockGap":"0","margin":{"top":"var:preset|spacing|medium","bottom":"0"}}},"textColor":"base","layout":{"inherit":true,"type":"constrained","wideSize":"100%"}} -->
<div class="wp-block-group has-base-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--medium);margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:columns {"verticalAlignment":"top","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|small","right":"var:preset|spacing|small"},"blockGap":{"top":"0"}}},"backgroundColor":"primary","textColor":"white"} -->
<div class="wp-block-columns are-vertically-aligned-top has-white-color has-primary-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--small)"><!-- wp:column {"verticalAlignment":"top","width":"33.33%","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|large","right":"var:preset|spacing|large"}}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large);flex-basis:33.33%"><!-- wp:site-logo {"align":"center"} /-->

<!-- wp:group {"style":{"spacing":{"blockGap":"4px"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"align":"center","style":{"typography":{"textTransform":"uppercase","fontSize":"0.9rem"}}} -->
<p class="has-text-align-center" style="font-size:0.9rem;text-transform:uppercase">© </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"placeholder":"Current year","metadata":{"bindings":{"content":{"source":"osom/current-year"}},"name":"Current Year"},"style":{"typography":{"textTransform":"uppercase","fontSize":"0.9rem"}},"className":"current-year"} -->
<p class="current-year" style="font-size:0.9rem;text-transform:uppercase">YYYY</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"textTransform":"none","fontSize":"0.9rem"}},"fontFamily":"heading"} -->
<p class="has-text-align-center has-heading-font-family" style="font-size:0.9rem;text-transform:none">-  OsomPress</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"33.33%","style":{"spacing":{"blockGap":"0","padding":{"right":"var:preset|spacing|large","left":"var:preset|spacing|large","top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}},"border":{"top":{"width":"0px","style":"none"},"right":{"width":"0px","style":"none"},"bottom":{"width":"0px","style":"none"},"left":{"color":"var:preset|color|white","width":"1px"}}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="border-top-style:none;border-top-width:0px;border-right-style:none;border-right-width:0px;border-bottom-style:none;border-bottom-width:0px;border-left-color:var(--wp--preset--color--white);border-left-width:1px;padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large);flex-basis:33.33%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color has-link-color">About Us</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontFamily":"heading"} -->
<p class="has-heading-font-family">With a dedicated team of three talented designers, we offer bespoke interior design services tailored to your unique needs. Our expertise spans residential, commercial, and corporate interiors, ensuring each project reflects your style and enhances your environment.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"33.33%","style":{"spacing":{"padding":{"right":"var:preset|spacing|large","left":"var:preset|spacing|large","top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}},"border":{"left":{"color":"var:preset|color|white","width":"1px"},"top":[],"right":[],"bottom":[]}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="border-left-color:var(--wp--preset--color--white);border-left-width:1px;padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large);flex-basis:33.33%"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color has-link-color">More Info</h3>
<!-- /wp:heading -->

<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"left","orientation":"vertical"},"style":{"spacing":{"blockGap":"0"}},"fontFamily":"heading"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
