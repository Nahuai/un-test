<?php
/**
 * Title: Home page alternative
 * Slug: uprising-next/page-home-2
 * Categories: osompages
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/hero-1.webp","id":163,"hasParallax":true,"dimRatio":0,"customOverlayColor":"#b5b4b1","isUserOverlayColor":true,"minHeight":300,"isDark":false,"align":"wide","className":"is-light","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","wideSize":"1040px"}} -->
<div class="wp-block-cover alignwide is-light has-parallax" style="margin-bottom:var(--wp--preset--spacing--50);min-height:300px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#b5b4b1"></span><div class="wp-block-cover__image-background wp-image-163 has-parallax" style="background-position:50% 50%;background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/hero-1.webp)"></div><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:pullquote {"className":"is-style-osom-quote"} -->
<figure class="wp-block-pullquote is-style-osom-quote"><blockquote><p>Good design is not just about aesthetics. It’s about making a space work for the people who use it, enhancing their experience, and improving their quality of life.</p><cite>David Collins</cite></blockquote></figure>
<!-- /wp:pullquote -->

<!-- wp:spacer {"height":"25px"} -->
<div style="height:25px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p>Our love for design goes beyond aesthetics. It's about creating spaces that reflect the personalities and lifestyles of those who inhabit them. From the initial concept to the final touches, our passion drives us to deliver spaces that are not only beautiful but also deeply personal.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We work closely with you from concept to completion, involving you in every step to ensure your vision is realized to perfection. We are committed to eco-friendly practices, using sustainable materials and energy-efficient solutions to create environmentally responsible designs.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"53px"} -->
<div style="height:53px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/featured-text"} /-->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"var:preset|spacing|x-large","bottom":"var:preset|spacing|x-large"}}}} -->
<p style="margin-top:var(--wp--preset--spacing--x-large);margin-bottom:var(--wp--preset--spacing--x-large)">We believe every project is unique. Our personalized approach ensures your space reflects your individual style and meets your specific needs. Our meticulous attention to detail ensures that every element of your design is crafted with precision and care.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"60px"} -->
<div style="height:60px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Latest Blog Posts:</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":2,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
<div class="wp-block-query"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:post-featured-image {"isLink":true,"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"0"}}}} /-->

<!-- wp:post-title {"level":4,"isLink":true,"style":{"spacing":{"padding":{"top":"0","bottom":"0"},"margin":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}}} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query -->

<!-- wp:spacer {"height":"59px"} -->
<div style="height:59px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/osom-boxes"} /-->
