<?php
/**
 * Title: The Team Block
 * Slug: uprising-next/the-team
 * Categories: osompress, team
 */
?>

<!-- wp:group {"metadata":{"name":"Our Team"},"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading {"textAlign":"center","className":"title"} -->
<h2 class="wp-block-heading has-text-align-center title">Meet Our Team</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"var:preset|spacing|small"} -->
<div style="height:var(--wp--preset--spacing--small)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"blockGap":{"top":"0","left":"var:preset|spacing|medium"}}},"textColor":"white"} -->
<div class="wp-block-columns alignwide has-white-color has-text-color has-link-color"><!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}}},"textColor":"theme-base"} -->
<div class="wp-block-column has-theme-base-color has-text-color has-link-color"><!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-primary-background-color has-background" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large);padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:image {"id":2593,"width":"92px","aspectRatio":"1","scale":"cover","sizeSlug":"thumbnail","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-thumbnail is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-avatar.svg" alt="" class="wp-image-2593" style="aspect-ratio:1;object-fit:cover;width:92px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">Emily Johnson</h3>
<!-- /wp:heading -->

<!-- wp:social-links {"iconColor":"theme-base","iconColorValue":"#ffffff","style":{"spacing":{"blockGap":{"left":"24px"},"margin":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"0","right":"0"}}},"className":"is-style-logos-only","layout":{"type":"flex","justifyContent":"center"}} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only" style="margin-top:var(--wp--preset--spacing--medium);margin-right:0;margin-bottom:var(--wp--preset--spacing--medium);margin-left:0"><!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /-->

<!-- wp:social-link {"url":"#","service":"youtube"} /-->

<!-- wp:social-link {"url":"https://wordpress.org","service":"wordpress"} /--></ul>
<!-- /wp:social-links -->

<!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">With over a decade of experience, Emily brings a keen eye for detail and a passion for creating timeless designs. Her expertise in color theory and spatial arrangement ensures every project is both beautiful and functional.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"textColor":"theme-base","layout":{"type":"default"}} -->
<div class="wp-block-column has-theme-base-color has-text-color has-link-color" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:image {"id":2593,"width":"92px","aspectRatio":"1","scale":"cover","sizeSlug":"thumbnail","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-thumbnail is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-avatar.svg" alt="" class="wp-image-2593" style="aspect-ratio:1;object-fit:cover;width:92px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">Sarah Williams</h3>
<!-- /wp:heading -->

<!-- wp:social-links {"iconColor":"theme-base","iconColorValue":"#ffffff","style":{"spacing":{"blockGap":{"left":"24px"},"margin":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}}},"className":"is-style-logos-only","layout":{"type":"flex","justifyContent":"center"}} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only" style="margin-top:var(--wp--preset--spacing--medium);margin-bottom:var(--wp--preset--spacing--medium)"><!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /-->

<!-- wp:social-link {"url":"#","service":"youtube"} /-->

<!-- wp:social-link {"url":"#","service":"wordpress"} /--></ul>
<!-- /wp:social-links -->

<!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">Sarah's organizational skills and design acumen keep projects on track and within budget. Her background in architecture adds a unique perspective to our design solutions, ensuring structural integrity and aesthetic excellence.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}}},"textColor":"theme-base"} -->
<div class="wp-block-column has-theme-base-color has-text-color has-link-color"><!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}},"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"0"},"padding":{"right":"var:preset|spacing|medium","left":"var:preset|spacing|medium","top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}},"backgroundColor":"primary","textColor":"theme-base","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-theme-base-color has-primary-background-color has-text-color has-background has-link-color" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:0;padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:image {"id":2593,"width":"92px","aspectRatio":"1","scale":"cover","sizeSlug":"large","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-large is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-avatar.svg" alt="" class="wp-image-2593" style="aspect-ratio:1;object-fit:cover;width:92px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">Michael Smith</h3>
<!-- /wp:heading -->

<!-- wp:social-links {"iconColor":"theme-base","iconColorValue":"#ffffff","style":{"spacing":{"blockGap":{"left":"24px"},"margin":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}}},"className":"is-style-logos-only","layout":{"type":"flex","justifyContent":"center"}} -->
<ul class="wp-block-social-links has-icon-color is-style-logos-only" style="margin-top:var(--wp--preset--spacing--medium);margin-bottom:var(--wp--preset--spacing--medium)"><!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /-->

<!-- wp:social-link {"url":"#","service":"youtube"} /-->

<!-- wp:social-link {"url":"https://wordpress.org","service":"wordpress"} /--></ul>
<!-- /wp:social-links -->

<!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">Michael's fresh ideas and innovative approach bring a modern touch to our projects. His enthusiasm for the latest design trends and technologies ensures our designs are always current and cutting-edge.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
