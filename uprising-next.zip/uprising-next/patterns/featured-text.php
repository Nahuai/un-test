<?php
/**
 * Title: Featured text
 * Slug: uprising-next/featured-text
 * Categories: osompress
 */
?>

<!-- wp:group {"className":"osom-featured-text","layout":{"type":"constrained"}} -->
<div class="wp-block-group osom-featured-text"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading -->
<h2 class="wp-block-heading">Our Office Interior Design Services</h2>
<!-- /wp:heading -->

<!-- wp:image {"id":15,"sizeSlug":"large","className":"is-style-default"} -->
<figure class="wp-block-image size-large is-style-default"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp" alt="" class="wp-image-15"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"spacing":{"margin":{"right":"-40px","left":"-40px"}}},"backgroundColor":"white"} -->
<p class="has-white-background-color has-background" style="margin-right:-40px;margin-left:-40px">At Calm Interiors, we transform office spaces into modern, efficient, and inspiring environments. Our interior design services are tailored to meet the unique needs of your business, enhancing productivity and employee well-being.<br><br>A well-designed office can boost morale and productivity. We create spaces that reflect your company's values and foster a positive work environment.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
