<?php
/**
 * Title: Testimonial Block
 * Slug: uprising-next/testimonial
 * Keywords: quote, review
 * Categories: osompress, testimonials, text
 */
?>
<!-- wp:group {"metadata":{"name":"Testimonials C","categories":["osompress"],"patternName":"uprising-next/testimonial"},"align":"wide","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"textAlign":"center","className":"title"} -->
<h2 class="wp-block-heading has-text-align-center title">Testimonials</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"style":{"spacing":{"padding":{"right":"var:preset|spacing|large","left":"var:preset|spacing|large","top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"blockGap":"0"},"shadow":"6px 6px 9px rgba(0, 0, 0, 0.2)"},"backgroundColor":"white"} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large);box-shadow:6px 6px 9px rgba(0, 0, 0, 0.2)"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Transformative Design Experience</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">"Working with Calm Interiors was a dream come true. Emily and the team transformed my house into a home that reflects my personality and style. Every detail was meticulously handled, and the result is simply stunning."</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"isStackedOnMobile":false,"style":{"spacing":{"margin":{"top":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns is-not-stacked-on-mobile" style="margin-top:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"><!-- wp:image {"id":2597,"width":"64px","sizeSlug":"large","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-large is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-small-avatar.svg" alt="" class="wp-image-2597" style="width:64px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"75%","style":{"spacing":{"blockGap":"0"}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:75%"><!-- wp:paragraph {"placeholder":"Content…","fontFamily":"heading"} -->
<p class="has-heading-font-family"><strong>Jane Doe</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Homeowner</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"shadow":"6px 6px 9px rgba(0, 0, 0, 0.2)","spacing":{"padding":{"right":"var:preset|spacing|large","left":"var:preset|spacing|large","top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}},"backgroundColor":"white"} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large);box-shadow:6px 6px 9px rgba(0, 0, 0, 0.2)"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Professional and Creative</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">"Calm Interiors did an amazing job redesigning our retail space. Sarah ensured everything was completed on time and within budget, while Michael’s creative touch brought a fresh and modern look that our customers love."</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"isStackedOnMobile":false,"style":{"spacing":{"margin":{"top":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns is-not-stacked-on-mobile" style="margin-top:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"><!-- wp:image {"id":2597,"width":"64px","sizeSlug":"large","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-large is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-small-avatar.svg" alt="" class="wp-image-2597" style="width:64px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"75%","style":{"spacing":{"blockGap":"0"}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:75%"><!-- wp:paragraph {"placeholder":"Content…","fontFamily":"heading"} -->
<p class="has-heading-font-family"><strong>John Smith</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Store Owner</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"shadow":"6px 6px 9px rgba(0, 0, 0, 0.2)","spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|large","right":"var:preset|spacing|large"}}},"backgroundColor":"white"} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large);box-shadow:6px 6px 9px rgba(0, 0, 0, 0.2)"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Exceptional Service and Results</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">"From start to finish, Calm Interiors provided exceptional service. Their attention to detail and commitment to excellence were evident in every phase of our office redesign. The new space is not only functional but also inspiring for our team."</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"isStackedOnMobile":false,"style":{"spacing":{"margin":{"top":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns is-not-stacked-on-mobile" style="margin-top:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"25%"} -->
<div class="wp-block-column" style="flex-basis:25%"><!-- wp:image {"id":2597,"width":"64px","sizeSlug":"large","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-large is-resized"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/placeholder-small-avatar.svg" alt="" class="wp-image-2597" style="width:64px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"75%","style":{"spacing":{"blockGap":"0"}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:75%"><!-- wp:paragraph {"placeholder":"Content…","fontFamily":"heading"} -->
<p class="has-heading-font-family"><strong>Emma Johnson</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>CEO, TechCorp</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->