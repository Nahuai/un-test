<?php
/**
 * Title: Featured content
 * Slug: uprising-next/featured-content
 * Categories: osompress
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:spacer {"height":"60px"} -->
<div style="height:60px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"className":"osom-featured-text"} -->
<div class="wp-block-columns osom-featured-text"><!-- wp:column {"width":"50%","style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|large","right":"var:preset|spacing|xx-large"}}},"backgroundColor":"white"} -->
<div class="wp-block-column has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--xx-large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large);flex-basis:50%"><!-- wp:heading -->
<h2 class="wp-block-heading">How Can We Help You</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>At Calm Interiors, we transform spaces into modern, efficient, and inspiring environments. Our custom interior design services are tailored to meet your specific needs and preferences. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We understand that your home is your sanctuary. Our goal is to create a living space that reflects your unique style and enhances your daily life.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"border":{"radius":"0px","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}},"className":"is-style-fill"} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link wp-element-button" style="border-width:1px;border-radius:0px;padding-top:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small)">LEARN MORE</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:image {"id":241,"sizeSlug":"large","className":"ml-40 mt-40"} -->
<figure class="wp-block-image size-large ml-40 mt-40"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp" alt="" class="wp-image-241"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
