<?php
/**
 * Title: Header with login
 * Slug: uprising-next/header-with-login
 * Categories: header
 * Block Types: core/template-part/header
 *
 * @package uprising-next
 * @since 0.9.0
 */
?>

<!-- wp:columns {"verticalAlignment":"center","align":"full","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}},"backgroundColor":"background"} -->
<div class="wp-block-columns alignfull are-vertically-aligned-center has-background-background-color has-background" style="padding-top:0;padding-right:var(--wp--preset--spacing--medium);padding-bottom:0;padding-left:var(--wp--preset--spacing--medium)"><!-- wp:column {"verticalAlignment":"center","width":""} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:site-title {"textAlign":"center","fontFamily":"heading"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":""} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:navigation {"textColor":"foreground","overlayBackgroundColor":"background","overlayTextColor":"primary","style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|medium"},"typography":{"textTransform":"uppercase"}},"fontSize":"small","fontFamily":"heading","layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center","orientation":"horizontal"}} /-->

<!-- wp:loginout {"displayLoginAsForm":true,"style":{"typography":{"textTransform":"uppercase"}},"fontSize":"small","fontFamily":"heading"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->