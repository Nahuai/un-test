<?php
/**
 * Title: Newsletter Placeholder
 * Slug: uprising-next/placeholder-newsletter
 * Inserter: no
 */
?>

<!-- wp:group {"metadata":{"name":"Newsletter Demo C"},"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|large","right":"var:preset|spacing|large"}}},"backgroundColor":"primary","textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide has-white-color has-primary-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large)"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color has-link-color">Join Us</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Subscribe to our newsletter for the latest on WordPress themes and plugins, delivered straight to your inbox. This way, you will never miss out on expert tips, product updates, and exclusive offers from OsomPress.*</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"style":{"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}}} -->
<div class="wp-block-columns" style="padding-top:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small)"><!-- wp:column {"verticalAlignment":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}},"backgroundColor":"white","textColor":"foreground"} -->
<div class="wp-block-column is-vertically-aligned-center has-foreground-color has-white-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small)"><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">First name</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"backgroundColor":"white","textColor":"foreground"} -->
<div class="wp-block-column has-foreground-color has-white-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small)"><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Email</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"backgroundColor":"secondary","textColor":"white"} -->
<div class="wp-block-column has-white-color has-secondary-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small)"><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Go</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">Privacy Policy</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size has-text-color has-link-color" style="color:#fa0000">*This is placeholder for you to replace it with your favourite form plugin</p>
<!-- /wp:paragraph --></div>

<!-- /wp:group -->
