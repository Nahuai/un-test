<?php
/**
 * Title: Header with centered logo
 * Slug: uprising-next/header-centered-logo
 * Categories: header
 * Block Types: core/template-part/header
 *
 * @package uprising-next
 * @since 0.9.0
 */
?>

<!-- wp:site-logo {"width":200,"shouldSyncIcon":true,"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}}}} /-->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large);padding-top:0;padding-right:var(--wp--preset--spacing--medium);padding-bottom:0;padding-left:var(--wp--preset--spacing--medium)"><!-- wp:navigation {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"blockGap":"var:preset|spacing|medium"},"typography":{"textTransform":"none","fontStyle":"normal","fontWeight":"500"}},"fontFamily":"heading"} /--></div>
<!-- /wp:group -->
