<?php
/**
 * Title: Header with top bar
 * Slug: uprising-next/header-with-top-bar
 * Categories: header
 * Block Types: core/template-part/header
 *
 * @package uprising-next
 * @since 0.9.0
 */
?>

<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"backgroundColor":"primary","textColor":"white","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group has-white-color has-primary-background-color has-text-color has-background has-link-color" style="padding-top:0;padding-right:var(--wp--preset--spacing--small);padding-bottom:0;padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph {"fontSize":"small","fontFamily":"heading"} -->
<p class="has-heading-font-family has-small-font-size">📍 Our address, 99, Barcelona (Spain).  📞 +3493123456 </p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","openInNewTab":true,"size":"has-small-icon-size","style":{"spacing":{"blockGap":{"top":"0","left":"var:preset|spacing|small"},"margin":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"0","right":"0"}}},"className":"is-style-logos-only","layout":{"type":"flex","justifyContent":"right"}} -->
<ul class="wp-block-social-links has-small-icon-size has-icon-color is-style-logos-only" style="margin-top:var(--wp--preset--spacing--small);margin-right:0;margin-bottom:var(--wp--preset--spacing--small);margin-left:0"><!-- wp:social-link {"url":"#","service":"wordpress"} /-->

<!-- wp:social-link {"url":"#","service":"twitter"} /-->

<!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"margin":{"top":"0","bottom":"0"},"blockGap":"0","padding":{"top":"0","right":"var:preset|spacing|medium","bottom":"0","left":"var:preset|spacing|medium"}}},"backgroundColor":"background","textColor":"base","layout":{"inherit":"true","type":"constrained"}} -->
<div class="wp-block-group has-base-color has-background-background-color has-text-color has-background has-link-color" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:var(--wp--preset--spacing--medium);padding-bottom:0;padding-left:var(--wp--preset--spacing--medium)"><!-- wp:group {"align":"full","style":{"spacing":{"padding":{"bottom":"30px","top":"30px","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}},"layout":{"type":"flex","justifyContent":"space-between"}} -->
<div class="wp-block-group alignfull" style="padding-top:30px;padding-right:var(--wp--preset--spacing--medium);padding-bottom:30px;padding-left:var(--wp--preset--spacing--medium)"><!-- wp:group {"style":{"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"flex"}} -->
<div class="wp-block-group" style="padding-right:0;padding-left:0"><!-- wp:site-title /--></div>
<!-- /wp:group -->

<!-- wp:navigation {"textColor":"foreground","overlayBackgroundColor":"background","overlayTextColor":"primary","layout":{"type":"flex","setCascadingProperties":true,"justifyContent":"center","orientation":"horizontal"},"style":{"spacing":{"margin":{"top":"0"},"blockGap":"var:preset|spacing|medium"},"typography":{"textTransform":"uppercase"}},"fontSize":"small","fontFamily":"heading"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->