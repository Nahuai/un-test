<?php
/**
 * Title: Project
 * Slug: uprising-next/page-project
 * Categories: osompages
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/hero-1.webp","id":98,"hasParallax":true,"dimRatio":0,"overlayColor":"background","isUserOverlayColor":true,"minHeight":405,"minHeightUnit":"px","isDark":false,"align":"full","style":{"border":{"width":"10px"}},"borderColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull is-light has-parallax has-border-color has-white-border-color" style="border-width:10px;min-height:405px"><span aria-hidden="true" class="wp-block-cover__background has-background-background-color has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__image-background wp-image-98 has-parallax" style="background-position:50% 50%;background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/hero-1.webp)"></div><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}}} -->
<h2 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large)">Interior Design Services for Retail Businesses</h2>
<!-- /wp:heading -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Custom Interior Design</h3>
<!-- /wp:heading -->

<!-- wp:separator {"align":"center","className":"is-style-osom-narrow-line","backgroundColor":"primary"} -->
<hr class="wp-block-separator aligncenter has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-osom-narrow-line"/>
<!-- /wp:separator --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"66.66%"} -->
<div class="wp-block-column" style="flex-basis:66.66%"><!-- wp:paragraph -->
<p>Our custom interior design services are tailored to meet your specific needs and preferences. Whether you’re looking to redesign a single room or your entire home, our team will work with you to create a cohesive and stylish design that suits your lifestyle.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Kitchen and Bathroom Remodeling</h3>
<!-- /wp:heading -->

<!-- wp:separator {"align":"center","className":"is-style-osom-narrow-line","style":{"spacing":{"margin":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}},"backgroundColor":"primary"} -->
<hr class="wp-block-separator aligncenter has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-osom-narrow-line" style="margin-top:var(--wp--preset--spacing--small);margin-bottom:var(--wp--preset--spacing--small)"/>
<!-- /wp:separator --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"66.66%"} -->
<div class="wp-block-column" style="flex-basis:66.66%"><!-- wp:paragraph -->
<p>Transform your kitchen and bathroom into stunning, functional spaces with our comprehensive remodeling services. From modern upgrades to complete overhauls, we’ll ensure these essential areas of your home are both beautiful and practical.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Living Room and Bedroom Design</h3>
<!-- /wp:heading -->

<!-- wp:separator {"align":"center","className":"is-style-osom-narrow-line","style":{"spacing":{"margin":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}},"backgroundColor":"primary"} -->
<hr class="wp-block-separator aligncenter has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-osom-narrow-line" style="margin-top:var(--wp--preset--spacing--small);margin-bottom:var(--wp--preset--spacing--small)"/>
<!-- /wp:separator --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"66.66%"} -->
<div class="wp-block-column" style="flex-basis:66.66%"><!-- wp:paragraph -->
<p>Create inviting and comfortable living spaces with our specialized living room and bedroom design services. We focus on creating environments that are both stylish and relaxing, perfect for unwinding and entertaining.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-columns" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large)"><!-- wp:column {"width":"33.33%"} -->
<div class="wp-block-column" style="flex-basis:33.33%"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size">Outdoor Living Spaces</h3>
<!-- /wp:heading -->

<!-- wp:separator {"align":"center","className":"is-style-osom-narrow-line","style":{"spacing":{"margin":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}},"backgroundColor":"primary"} -->
<hr class="wp-block-separator aligncenter has-text-color has-primary-color has-alpha-channel-opacity has-primary-background-color has-background is-style-osom-narrow-line" style="margin-top:var(--wp--preset--spacing--small);margin-bottom:var(--wp--preset--spacing--small)"/>
<!-- /wp:separator --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"66.66%"} -->
<div class="wp-block-column" style="flex-basis:66.66%"><!-- wp:paragraph -->
<p>Extend your living space outdoors with our expert design services. From cozy patios to luxurious gardens, we’ll help you create an outdoor oasis that you can enjoy year-round.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:pattern {"slug":"uprising-next/cta"} /-->

<!-- wp:gallery {"linkTo":"none"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-cropped"><!-- wp:image {"id":108,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/blog-1.webp" alt="" class="wp-image-108"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":62,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-1.webp" alt="" class="wp-image-62"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":68,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp" alt="" class="wp-image-68"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":106,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-2.webp" alt="" class="wp-image-106"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":107,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/product-1.webp" alt="" class="wp-image-107"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":108,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/blog-1.webp" alt="" class="wp-image-108"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">At Calm Interiors, we transform office spaces into modern, efficient, and inspiring environments. Our interior design services are tailored to meet the unique needs of your business, enhancing productivity and employee well-being.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"metadata":{"name":"What we offer"},"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|xx-large","bottom":"var:preset|spacing|xx-large"},"padding":{"right":"0","left":"0"},"blockGap":"0"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="margin-top:var(--wp--preset--spacing--xx-large);margin-bottom:var(--wp--preset--spacing--xx-large);padding-right:0;padding-left:0"><!-- wp:heading {"textAlign":"center","className":"title"} -->
<h2 class="wp-block-heading has-text-align-center title">What We Offer</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"var:preset|spacing|small"} -->
<div style="height:var(--wp--preset--spacing--small)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"blockGap":{"top":"0","left":"var:preset|spacing|small"},"padding":{"right":"0","left":"0"}}},"textColor":"white"} -->
<div class="wp-block-columns alignwide has-white-color has-text-color has-link-color" style="padding-right:0;padding-left:0"><!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}}},"textColor":"theme-base"} -->
<div class="wp-block-column has-theme-base-color has-text-color has-link-color"><!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"},"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-primary-background-color has-background" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large);padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:image {"id":107,"scale":"cover","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/product-1.webp" alt="" class="wp-image-107" style="object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">Landscape Design</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-text-align-center has-white-color has-text-color has-link-color">Our designers will create a beautiful and functional landscape plan tailored to your needs.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"textColor":"theme-base","layout":{"type":"default"}} -->
<div class="wp-block-column has-theme-base-color has-text-color has-link-color" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:image {"id":107,"scale":"cover","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/product-1.webp" alt="" class="wp-image-107" style="object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">Outdoor Furniture</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">We'll assist you in selecting stylish and durable outdoor furniture and decor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-base"}}}},"textColor":"theme-base"} -->
<div class="wp-block-column has-theme-base-color has-text-color has-link-color"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}},"backgroundColor":"primary","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-primary-background-color has-background" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large);padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:image {"id":107,"scale":"cover","sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/product-1.webp" alt="" class="wp-image-107" style="object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">Lighting and Feature</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size">Enhance your outdoor space with custom lighting and unique features like fire pits, water features, and more.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|large","right":"var:preset|spacing|large"}}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large)"><!-- wp:heading -->
<h2 class="wp-block-heading">Our Story: How We Met</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><br>In the bustling heart of Cityville, fate brought us together at a local design expo. I remember it vividly; I was showcasing my expertise in color theory and spatial arrangement, while Sarah was presenting her architectural designs, and Michael was demonstrating his innovative approach to modern design trends.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><br>As the day went on, I found myself drawn to Sarah's meticulous attention to detail and Michael's fresh ideas and creative flair. During a break, we happened to sit at the same table and began discussing our design philosophies and dreams for the future. It didn't take long for us to realize that we shared a common vision: to create beautiful, functional, and personalized spaces that tell a story.... </p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large)"><!-- wp:button {"className":"is-style-osom-button"} -->
<div class="wp-block-button is-style-osom-button"><a class="wp-block-button__link wp-element-button" href="#">read more</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-osom-button"} -->
<div class="wp-block-button is-style-osom-button"><a class="wp-block-button__link wp-element-button">CONTACT US</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->