<?php
/**
 * Title: About Us
 * Slug: uprising-next/page-about-us
 * Categories: osompages
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/hero-1.webp","id":188,"dimRatio":0,"minHeight":339,"minHeightUnit":"px","align":"full","className":"is-light"} -->
<div class="wp-block-cover alignfull is-light" style="min-height:339px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-188" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/hero-1.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title...","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"align":"wide","className":"mt-40","backgroundColor":"theme-base","layout":{"type":"constrained","wideSize":"","contentSize":""}} -->
<div class="wp-block-group alignwide mt-40 has-theme-base-background-color has-background"><!-- wp:columns {"style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium","right":"var:preset|spacing|medium"},"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|30"}}},"backgroundColor":"white"} -->
<div class="wp-block-columns has-white-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:column {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}}},"backgroundColor":"secondary","textColor":"white"} -->
<div class="wp-block-column has-white-color has-secondary-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--70)"><!-- wp:heading {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h2 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">About Us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>At Calm Interiors, we believe that every space tells a story. Founded by a trio of passionate designers, our journey began with a shared vision: to create environments that inspire, comfort, and transform. </p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}}}} -->
<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:paragraph -->
<p>Our team, consisting of Emily, Sarah, and Michael, combines a rich blend of experience, creativity, and innovation to bring each client's unique vision to life. From the beginning, our mission has been to provide personalized and thoughtful design solutions that go beyond aesthetics. We take pride in our collaborative approach, working closely with clients to understand their needs and preferences.&nbsp;This commitment to excellence and client satisfaction is what sets us apart and drives us to continually evolve and improve our services.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"61px"} -->
<div style="height:61px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/features"} /-->
<!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/gallery-with-round-corners"} /-->

<!-- wp:spacer {"height":"75px"} -->
<div style="height:75px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/the-team"} /-->

<!-- wp:spacer {"height":"65px"} -->
<div style="height:65px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/featured-text"} /-->

<!-- wp:spacer {"height":"65px"} -->
<div style="height:65px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:pattern {"slug":"uprising-next/cta"} /-->