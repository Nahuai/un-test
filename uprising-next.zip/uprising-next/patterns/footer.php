<?php
/**
 * Title: Footer
 * Slug: uprising-next/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 */
?>

<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"spacing":{"padding":{"top":"var:preset|spacing|40","right":"0","bottom":"var:preset|spacing|40","left":"0"},"blockGap":"0","margin":{"top":"var:preset|spacing|70","bottom":"0"}}},"backgroundColor":"secondary","textColor":"base","layout":{"inherit":true,"type":"constrained","wideSize":"100%"}} -->
<div class="wp-block-group has-base-color has-secondary-background-color has-text-color has-background has-link-color" style="margin-top:var(--wp--preset--spacing--70);margin-bottom:0;padding-top:var(--wp--preset--spacing--40);padding-right:0;padding-bottom:var(--wp--preset--spacing--40);padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","right":"0","bottom":"var:preset|spacing|20"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:0;padding-bottom:var(--wp--preset--spacing--20)"><!-- wp:group {"style":{"spacing":{"blockGap":"4px"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"align":"center","style":{"typography":{"textTransform":"uppercase","fontSize":"0.9rem"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:0.9rem;text-transform:uppercase">© </p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"placeholder":"Current year","metadata":{"bindings":{"content":{"source":"osom/current-year"}},"name":"Current Year"},"style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"textColor":"background","className":"current-year"} -->
<p class="current-year has-background-color has-text-color has-link-color">YYYY</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"align":"center","style":{"typography":{"textTransform":"uppercase","fontSize":"0.9rem"}},"textColor":"background"} -->
<p class="has-text-align-center has-background-color has-text-color" style="font-size:0.9rem;text-transform:uppercase"> - Uprising Next Theme by OsomPress</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
