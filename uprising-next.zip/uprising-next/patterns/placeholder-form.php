<?php
/**
 * Title: Form Placeholder
 * Slug: uprising-next/placeholder-form
 * Inserter: no
 */
?>
<!-- wp:group {"metadata":{"name":"Form Placeholder"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"color":{"text":"#fa0000"},"elements":{"link":{"color":{"text":"#fa0000"}}}}} -->
<p class="has-text-color has-link-color" style="color:#fa0000">*This is placeholder for you to replace it with your favourite form plugin</p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"border":{"width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground"} -->
<div class="wp-block-column has-border-color has-foreground-border-color" style="border-width:1px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Name</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"border":{"width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground"} -->
<div class="wp-block-column has-border-color has-foreground-border-color" style="border-width:1px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Email</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"style":{"border":{"radius":"1px","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-foreground-border-color" style="border-width:1px;border-radius:1px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Subject</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"dimensions":{"minHeight":"250px"},"border":{"width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-foreground-border-color" style="border-width:1px;min-height:250px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Message</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"width":100,"style":{"typography":{"textTransform":"uppercase"},"border":{"radius":"0px"}}} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100" style="text-transform:uppercase"><a class="wp-block-button__link wp-element-button" style="border-radius:0px">Submit</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
