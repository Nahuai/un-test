<?php
/**
 * Title: Faq's
 * Slug: uprising-next/faq
 * Keywords: faq, frequently asked
 * Categories: osompress, text
 */
?>

<!-- wp:details {"showContent":true,"className":"is-style-osom-details-with-color-and-border"} -->
<details class="wp-block-details is-style-osom-details-with-color-and-border" open><summary>What services do you offer at Calm Interiors?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block","style":{"spacing":{"padding":{"right":"var:preset|spacing|small","left":"var:preset|spacing|small"}}}} -->
<p style="padding-right:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)">At Calm Interiors, we offer a wide range of interior design services tailored to meet the needs of our clients. Our services include residential design, commercial design, and corporate design. We provide everything from initial consultations and design concepts to detailed design plans and project management. Our goal is to create beautiful and functional spaces that reflect your style and meet your specific needs.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-osom-details-with-color-and-border"} -->
<details class="wp-block-details is-style-osom-details-with-color-and-border"><summary>How does the design process work?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block","style":{"spacing":{"padding":{"right":"var:preset|spacing|small","left":"var:preset|spacing|small"}}}} -->
<p style="padding-right:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)">The design process at Calm Interiors is collaborative and client-focused. It begins with an initial consultation where we discuss your vision, preferences, and requirements. Following this, our team develops design concepts and detailed plans. We involve you at every stage to ensure the final design aligns with your expectations. Regular updates and on-site visits are part of our process to ensure seamless execution and high-quality results.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-osom-details-with-color-and-border"} -->
<details class="wp-block-details is-style-osom-details-with-color-and-border"><summary>What should I expect during the initial consultation?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block","style":{"spacing":{"padding":{"right":"var:preset|spacing|small","left":"var:preset|spacing|small"}}}} -->
<p style="padding-right:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)">During the initial consultation, we will discuss your project in detail. This includes understanding your style preferences, the scope of the project, budget, and timeline. We will also explore any specific requirements or challenges you may have. This meeting helps us gather all necessary information to create a design plan that perfectly suits your needs. It’s also a great opportunity for you to ask any questions and get to know our team.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
