<?php
/**
 * Title: Pricing Table
 * Slug: uprising-next/pricing-table
 * Categories: osompress, pricing table
 *
 * @package uprising-next
 * @since 0.9.0
 */
?>

<!-- wp:group {"metadata":{"name":"Pricing List","categories":["osompress"],"patternName":"uprising-next/pricing-table"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"400px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Pricing List</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"paragraph-1"} -->
<p class="has-text-align-center paragraph-1">Choose the Perfect Plan for Your Space</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"var:preset|spacing|small"} -->
<div style="height:var(--wp--preset--spacing--small)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"border":{"width":"1px"},"spacing":{"padding":{"right":"var:preset|spacing|medium","left":"var:preset|spacing|medium","top":"var:preset|spacing|x-large","bottom":"var:preset|spacing|x-large"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"}},"borderColor":"theme-text"} -->
<div class="wp-block-group has-border-color has-theme-text-border-color" style="border-width:1px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--x-large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--x-large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size"><strong>Basic Plan</strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"36px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"600"}},"fontFamily":"heading"} -->
<p class="has-text-align-center has-heading-font-family" style="font-size:36px;font-style:normal;font-weight:600;line-height:1.5"><strong> </strong>100€</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Month</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|medium"}}},"fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--medium)">Perfect for small-scale projects and quick updates. Includes initial consultation, custom design solutions, and email support.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"theme-primary","textColor":"theme-base"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-theme-base-color has-theme-primary-background-color has-text-color has-background wp-element-button">START Now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"border":{"width":"1px","color":"#323B3C"},"spacing":{"padding":{"right":"var:preset|spacing|medium","left":"var:preset|spacing|medium","top":"var:preset|spacing|x-large","bottom":"var:preset|spacing|x-large"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"backgroundColor":"primary","textColor":"white"} -->
<div class="wp-block-group has-border-color has-white-color has-primary-background-color has-text-color has-background has-link-color" style="border-color:#323B3C;border-width:1px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--x-large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--x-large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color has-large-font-size"><strong><strong>Standard Plan</strong></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"36px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"600"}},"fontFamily":"heading"} -->
<p class="has-text-align-center has-heading-font-family" style="font-size:36px;font-style:normal;font-weight:600;line-height:1.5"><strong> </strong>180€</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Month</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|medium"}}},"fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--medium)">Ideal for comprehensive residential or small business designs. Includes basic plan plus on-site visits, and phone support.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-osom-white-button"} -->
<div class="wp-block-button is-style-osom-white-button"><a class="wp-block-button__link wp-element-button">START NOW</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"wp-block-column0"} -->
<div class="wp-block-column wp-block-column0"><!-- wp:group {"style":{"border":{"width":"1px"},"spacing":{"padding":{"right":"var:preset|spacing|medium","left":"var:preset|spacing|medium","top":"var:preset|spacing|x-large","bottom":"var:preset|spacing|x-large"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"}},"borderColor":"theme-text"} -->
<div class="wp-block-group has-border-color has-theme-text-border-color" style="border-width:1px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--x-large);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--x-large);padding-left:var(--wp--preset--spacing--medium)"><!-- wp:heading {"textAlign":"center","level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-text-align-center has-large-font-size"><strong><strong>Premium Plan</strong></strong></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"36px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"600"}},"fontFamily":"heading"} -->
<p class="has-text-align-center has-heading-font-family" style="font-size:36px;font-style:normal;font-weight:600;line-height:1.5"><strong> </strong>260€</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Month</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|medium"}}},"fontSize":"small"} -->
<p class="has-text-align-center has-small-font-size" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--medium)">Best for large-scale projects and corporate clients. Includes standard plan + priority support, and project management services.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"theme-primary","textColor":"theme-base"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-theme-base-color has-theme-primary-background-color has-text-color has-background wp-element-button">START Now</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
