<?php
/**
 * Title: Gallery with round corners
 * Slug: uprising-next/gallery-with-round-corners
 * Categories: osompress, gallery
 */
?>

<!-- wp:columns {"className":"uprising-gallery"} -->
<div class="wp-block-columns uprising-gallery"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp","id":11,"dimRatio":0,"style":{"border":{"radius":{"topLeft":"40px"}}},"className":"is-light"} -->
<div class="wp-block-cover is-light" style="border-top-left-radius:40px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-11" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-1.webp","id":26,"dimRatio":0,"className":"is-light"} -->
<div class="wp-block-cover is-light"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-26" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-1.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-2.webp","id":24,"dimRatio":0,"style":{"border":{"radius":{"bottomRight":"40px"}}},"className":"is-light"} -->
<div class="wp-block-cover is-light" style="border-bottom-right-radius:40px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-24" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-2.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
