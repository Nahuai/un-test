<?php
/**
 * Title: Boxes block layout
 * Slug: uprising-next/osom-boxes
 * Categories: osompress
 */
?>

<!-- wp:group {"metadata":{"categories":["osompress"],"patternName":"uprising-next/osom-boxes","name":"Boxes block layout"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Getting To Know Each Other</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Ready to transform your space? Reach out to us today to schedule a consultation. Let Calm Interiors bring your dream space to life.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"osom-boxes","layout":{"type":"constrained"}} -->
<div class="wp-block-group osom-boxes"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:cover {"overlayColor":"secondary","isUserOverlayColor":true,"minHeight":0,"minHeightUnit":"px","className":"is-light","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"border":{"radius":{"topRight":"40px"},"left":{"color":"#e2e1e1","width":"10px"},"top":[],"right":[],"bottom":[]}},"textColor":"white"} -->
<div class="wp-block-cover is-light has-white-color has-text-color has-link-color" style="border-top-right-radius:40px;border-left-color:#e2e1e1;border-left-width:10px"><span aria-hidden="true" class="wp-block-cover__background has-secondary-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:heading {"textAlign":"center","level":3,"className":"has-white-color has-text-color has-link-color"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">About You</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">We want to know more about you</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-osom-white-button","style":{"border":{"width":"0px","style":"none","radius":"0px"},"spacing":{"padding":{"left":"var:preset|spacing|large","right":"var:preset|spacing|large","top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}}} -->
<div class="wp-block-button is-style-osom-white-button"><a class="wp-block-button__link wp-element-button" style="border-style:none;border-width:0px;border-radius:0px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--large)">CONTACT US</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:cover {"overlayColor":"secondary","isUserOverlayColor":true,"minHeight":0,"minHeightUnit":"px","className":"is-light","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"border":{"radius":{"topRight":"40px"},"left":{"color":"var:preset|color|tertiary","width":"10px"},"top":[],"right":[],"bottom":[]}},"textColor":"white"} -->
<div class="wp-block-cover is-light has-white-color has-text-color has-link-color" style="border-top-right-radius:40px;border-left-color:var(--wp--preset--color--tertiary);border-left-width:10px"><span aria-hidden="true" class="wp-block-cover__background has-secondary-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color">About Us</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Know more about the team</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-osom-white-button","style":{"spacing":{"padding":{"left":"var:preset|spacing|large","right":"var:preset|spacing|large","top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}},"border":{"width":"0px","style":"none","radius":"0px"}}} -->
<div class="wp-block-button is-style-osom-white-button"><a class="wp-block-button__link wp-element-button" style="border-style:none;border-width:0px;border-radius:0px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--large)">OUR TEAM</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->