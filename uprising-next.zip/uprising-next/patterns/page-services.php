<?php
/**
 * Title: Services
 * Slug: uprising-next/page-services
 * Categories: osompages
 * Keywords: starter
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>

<!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-1.webp","id":62,"dimRatio":50,"overlayColor":"foreground","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|xx-large","bottom":"var:preset|spacing|xx-large"}},"elements":{"heading":{"color":{"text":"var:preset|color|background"}},"link":{"color":{"text":"var:preset|color|background"}}}},"textColor":"background","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull has-background-color has-text-color has-link-color" style="padding-top:var(--wp--preset--spacing--xx-large);padding-bottom:var(--wp--preset--spacing--xx-large)"><span aria-hidden="true" class="wp-block-cover__background has-foreground-background-color has-background-dim"></span><img class="wp-block-cover__image-background wp-image-62" alt="" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-1.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:heading {"textAlign":"center","level":1,"style":{"spacing":{"padding":{"top":"0","bottom":"0"},"margin":{"top":"0","bottom":"0"}},"typography":{"fontSize":"3.3rem","lineHeight":1.4}}} -->
<h1 class="wp-block-heading has-text-align-center" style="margin-top:0;margin-bottom:0;padding-top:0;padding-bottom:0;font-size:3.3rem;line-height:1.4"><strong>Welcome to Your Dream Space</strong></h1>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|large"}},"typography":{"lineHeight":"1.3"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--large);line-height:1.3">At Elegance Interiors, we transform spaces into stunning works of art.</h2>
<!-- /wp:heading -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-fill"} -->
<div class="wp-block-button is-style-fill"><a class="wp-block-button__link wp-element-button">Contact Us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--large)"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center"><strong>Crafting Spaces with Heart</strong></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">At Calm Interiors, we believe that every space tells a story. Founded by a trio of passionate designers, our journey began with a shared vision: to create environments that inspire, comfort, and transform. Our team, consisting of Emily, Sarah, and Michael, combines a rich blend of experience, creativity, and innovation to bring each client's unique vision to life.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:media-text {"align":"wide","mediaId":68,"mediaLink":"","mediaType":"image","verticalAlignment":"center","imageFill":true} -->
<div class="wp-block-media-text alignwide is-stacked-on-mobile is-vertically-aligned-center is-image-fill"><figure class="wp-block-media-text__media" style="background-image:url(<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp);background-position:50% 50%"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-3.webp" alt="" class="wp-image-68 size-full"/></figure><div class="wp-block-media-text__content"><!-- wp:heading {"style":{"typography":{"lineHeight":1.4}}} -->
<h2 class="wp-block-heading" style="line-height:1.4"><strong>At Elegance Interiors, we transform spaces into stunning works of art.</strong></h2>
<!-- /wp:heading -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Welcome to Your Dream Space</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>With a dedicated team of three talented designers, we offer bespoke interior design services tailored to your unique needs. Our expertise spans residential, commercial, and corporate interiors, ensuring each project reflects your style and enhances your environment.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--medium);margin-bottom:var(--wp--preset--spacing--medium)"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">SEE MORE</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {"align":"wide","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|x-large","right":"var:preset|spacing|x-large"},"blockGap":{"top":"var:preset|spacing|medium","left":"var:preset|spacing|xx-large"},"margin":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large"}}},"backgroundColor":"secondary","textColor":"white"} -->
<div class="wp-block-columns alignwide has-white-color has-secondary-background-color has-text-color has-background has-link-color" style="margin-top:var(--wp--preset--spacing--large);margin-bottom:var(--wp--preset--spacing--large);padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--x-large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--x-large)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h3 class="wp-block-heading has-white-color has-text-color has-link-color">Residential Design</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Transform your home into a sanctuary of comfort and beauty. From cozy apartments to luxurious villas, we bring your vision to life with meticulous attention to detail.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":62,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/page-1.webp" alt="" class="wp-image-62"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"body"} -->
<h4 class="wp-block-heading has-white-color has-text-color has-link-color has-body-font-family"><strong>Commercial Design</strong></h4>
<!-- /wp:heading -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph -->
<p>Create inviting and functional retail spaces that captivate customers. Our designs not only look stunning but also enhance the shopping experience, driving sales and customer satisfaction.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"34px"} -->
<div style="height:34px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"level":4,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"body"} -->
<h4 class="wp-block-heading has-white-color has-text-color has-link-color has-body-font-family"><strong>Corporate Design</strong></h4>
<!-- /wp:heading -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph -->
<p>Elevate your workplace with modern, efficient, and inspiring office designs. We craft environments that foster productivity, creativity, and employee well-being.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"34px"} -->
<div style="height:34px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|large"},"padding":{"right":"var:preset|spacing|small","left":"var:preset|spacing|small","top":"var:preset|spacing|small","bottom":"var:preset|spacing|small"}}}} -->
<div class="wp-block-columns alignwide" style="padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ready to transform your space? </h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Reach out to us today to schedule a consultation. Let Elegance Interiors bring your dream space to life.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"metadata":{"name":"Form Placeholder"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"border":{"width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground"} -->
<div class="wp-block-column has-border-color has-foreground-border-color" style="border-width:1px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Name</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"border":{"width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground"} -->
<div class="wp-block-column has-border-color has-foreground-border-color" style="border-width:1px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Email</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"style":{"border":{"radius":"1px","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-foreground-border-color" style="border-width:1px;border-radius:1px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Subject</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"dimensions":{"minHeight":"250px"},"border":{"width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|small","bottom":"var:preset|spacing|small","left":"var:preset|spacing|small","right":"var:preset|spacing|small"}}},"borderColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-foreground-border-color" style="border-width:1px;min-height:250px;padding-top:var(--wp--preset--spacing--small);padding-right:var(--wp--preset--spacing--small);padding-bottom:var(--wp--preset--spacing--small);padding-left:var(--wp--preset--spacing--small)"><!-- wp:paragraph -->
<p>Message</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"width":100,"style":{"typography":{"textTransform":"uppercase"},"border":{"radius":"0px"}}} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100" style="text-transform:uppercase"><a class="wp-block-button__link wp-element-button" style="border-radius:0px">Submit</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"style":{"color":{"text":"#fa0000"},"elements":{"link":{"color":{"text":"#fa0000"}}}},"fontSize":"small"} -->
<p class="has-text-color has-link-color has-small-font-size" style="color:#fa0000">*This is placeholder for you to replace it with your favourite form plugin</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:pattern {"slug":"uprising-next/faq"} /-->
</div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"29px"} -->
<div style="height:29px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->